//
//  TableViewCell.swift
//  iclode test
//
//  Created by Dev on 11/02/19.
//  Copyright © 2019 Dev. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var txt : UITextField!
    @IBOutlet var lbl1 : UILabel!
    @IBOutlet var lbl2 : UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        txt.delegate = self
    }

    static var identifier : String{
        return String(describing: self)
    }
    
    static var nib : UINib{
        return UINib(nibName: identifier, bundle: nil)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func isValidPassword(str:String) -> Bool {
        let passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[d$@$!%*?&#])[A-Za-z\\dd$@$!%*?&#]{8,}"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: str)
    }
}
extension TableViewCell : UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text, let textRange = Range(range, in: text) {
            let updatedText = text.replacingCharacters(in: textRange,with: string)
            if updatedText.characters.count<8{
                lbl1.text = "invalis"
                lbl2.text = "invalis amdjhas"
            }else{
                lbl1.text = ""
                if  !isValidPassword(str: updatedText){
                    lbl2.text = "invalis sdfgshd"
                }else{
                    lbl2.text = ""
                }
            }
            
        }
        return true
    }
}
