//
//  ViewController.swift
//  iclode test
//
//  Created by Dev on 03/02/19.
//  Copyright © 2019 Dev. All rights reserved.
//

import UIKit
import CloudKit
class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    var imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
      // copyDocumentsToiCloudDrive()
    }
    func copyDocumentsToiCloudDrive() {
        var error: NSError?
        let iCloudDocumentsURL = FileManager.default.url(forUbiquityContainerIdentifier: nil)?.appendingPathComponent("myCloudTest")
        
        do{
            //is iCloud working?
            if  iCloudDocumentsURL != nil {
                //Create the Directory if it doesn't exist
                if (!FileManager.default.fileExists(atPath: iCloudDocumentsURL!.path, isDirectory: nil)) {
                    //This gets skipped after initial run saying directory exists, but still don't see it on iCloud
                    try FileManager.default.createDirectory(at: iCloudDocumentsURL!, withIntermediateDirectories: true, attributes: nil)
                }
            } else {
                print("iCloud is NOT working!")
                //  return
            }
            
            if error != nil {
                print("Error creating iCloud DIR")
            }
            
            //Set up directorys
            let localDocumentsURL = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: .userDomainMask).last! as NSURL
            
            //Add txt file to my local folder
            let myTextString = NSString(string: "HELLO WORLD")
            let myLocalFile = localDocumentsURL.appendingPathComponent("myTextFile.txt")
            _ = try myTextString.write(to: myLocalFile!, atomically: true, encoding: String.Encoding.utf8.rawValue)
            
            if ((error) != nil){
                print("Error saving to local DIR")
            }
            
            //If file exists on iCloud remove it
            var isDir:ObjCBool = false
            if (FileManager.default.fileExists(atPath: iCloudDocumentsURL!.path, isDirectory: &isDir)) {
                try FileManager.default.removeItem(at: iCloudDocumentsURL!)
            }
            
            //copy from my local to iCloud
            if error == nil {
                try FileManager.default.copyItem(at: localDocumentsURL as URL, to: iCloudDocumentsURL!)
            }
        }
        catch let error{
            print(error.localizedDescription,"      Error creating a file")
        }
        
    }
    @IBAction func buttonOnClick(_ sender: UIButton)
    {
       
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        /*If you want work actionsheet on ipad
         then you have to use popoverPresentationController to present the actionsheet,
         otherwise app will crash on iPad */
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            alert.popoverPresentationController?.sourceView = sender
            alert.popoverPresentationController?.sourceRect = sender.bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let img = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
            copyDocumentsToiCloud(img)
        }
        picker.dismiss(animated: true,completion: nil)

    }

    func openGallary()
    {
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    let documentsDirectoryPath:NSString = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
    var imageURL: URL!
    let tempImageName = "Image2.jpg"
    
    
    func saveImage(_ image: UIImage?) {
        let newRecord:CKRecord = CKRecord(recordType: "image")
        if let image = image {
            let imageData:Data = image.jpegData(compressionQuality: 1)!
            let path:String = self.documentsDirectoryPath.appendingPathComponent(self.tempImageName)
            self.imageURL = URL(fileURLWithPath: path)
            try? imageData.write(to: self.imageURL, options: [.atomic])
            
            let File:CKAsset?  = CKAsset(fileURL: URL(fileURLWithPath: path))
            newRecord.setObject(File, forKey: "cameaimgh")
        }
        let publicDB = CKContainer.default().publicCloudDatabase
            publicDB.save(newRecord, completionHandler: { (record:CKRecord?, error:Error?) in
                
                // Check if there was an error
                if error != nil {
                    NSLog((error?.localizedDescription)!)
                }
                else if record != nil {
                   print("success")
                }
                
            })
            
            
        }
    func copyDocumentsToiCloud(_ image: UIImage?) {
       
        let file = "\(randomString(length: 20)).jpg"
        let contents = "Some text..."
        
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = dir.appendingPathComponent(file)
        
        do {
            if let data = image?.jpegData(compressionQuality:1),
                !FileManager.default.fileExists(atPath: fileURL.path) {
                do {
                    // writes the image data to disk
                    try data.write(to: fileURL)
                    print("file saved")
                } catch {
                    print("error saving file:", error)
                }
            }

           // try contents.write(to: fileURL, atomically: false, encoding: .utf8)
        }
        catch {
            print("Error: \(error)")
        }
        
    }
    func randomString(length: Int) -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0...length-1).map{ _ in letters.randomElement()! })
    }
}
